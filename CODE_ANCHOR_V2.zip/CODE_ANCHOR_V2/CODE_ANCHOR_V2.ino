#include <BLEDevice.h>
#include <BLEScan.h>
#include <BLEAdvertisedDevice.h>
 
BLEScan* pBLEScan;
 
// UUID recherché
BLEUUID targetUUID("12345678-1234-1234-1234-1234567890ab");
 
void setup() {
  Serial.begin(115200);
 
  BLEDevice::init("");              // initialise le BLE
  pBLEScan = BLEDevice::getScan();  // crée le scanner
 
  pBLEScan->setActiveScan(true);    // IMPORTANT : permet de récupérer le nom
}
 
void loop() {
  BLEScanResults* results = pBLEScan->start(3); // scan pendant 3 secondes
 
  for (int i = 0; i < results->getCount(); i++) {
    BLEAdvertisedDevice device = results->getDevice(i);
 
    // Vérifie si l'appareil a le bon UUID
    if (device.haveServiceUUID() && device.getServiceUUID().equals(targetUUID)) {
      int rssi = device.getRSSI();
 
      if (device.haveName()) {
        Serial.print("Nom: ");
        Serial.println(device.getName().c_str());
      } else {
        Serial.println("Nom: inconnu");
      }
 
      Serial.print("RSSI: ");
      Serial.println(rssi);
 
      Serial.print("MAC: ");
      Serial.println(device.getAddress().toString().c_str());
      Serial.println("-------------------");
    }
  }
 
  pBLEScan->clearResults(); // libère la mémoire
  delay(1000);
}